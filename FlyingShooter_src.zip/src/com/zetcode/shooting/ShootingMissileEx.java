package com.zetcode.shooting;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class ShootingMissileEx extends JFrame {

    public ShootingMissileEx() {

        initUI();
    }

    private void initUI() {

        add(new Board());

        setSize(400, 300);
        setResizable(false);

        setTitle("Shooting missiles");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {
            ShootingMissileEx ex = new ShootingMissileEx();
            ex.setVisible(true);
        });
    }
}