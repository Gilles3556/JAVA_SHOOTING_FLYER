package pndgV3.model;

import pndgV3.ihm.Commons;

public class Alien extends Sprite {

    public Alien( int x, int y ){
        super(x,y, TypeSprite.ALIEN);
    }

    public String toString(){
        return "Alien : x="+getX()+": y="+getY();
    }

    public void move() {
        //System.out.println(" move() like a "+this.getClass().getSimpleName().toUpperCase());
        move(Commons.ALIEN_SPEED*-1,0);
    }


}
