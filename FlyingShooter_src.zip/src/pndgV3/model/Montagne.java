package pndgV3.model;

import pndgV3.ihm.Commons;

public class Montagne extends Sprite {
    private boolean touched;

    public boolean isTouched() {
        return touched;
    }

    public Montagne( int y) {
        super(Commons.X_DEPART,y, TypeSprite.MONTAGNE);
        touched=false;
    }

    public void etreTouche(){
        touched=true;
    }

    public void move() {
        //System.out.println(" move() like a "+this.getClass().getSimpleName().toUpperCase());

        move(Commons.MONTAGNE_SPEED*-1,0);
    }
    public String toString(){
        return this.getClass().getSimpleName().toUpperCase()+" "+super.toString();
    }
}
