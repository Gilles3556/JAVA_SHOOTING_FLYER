package pndgV3.model;

import pndgV3.ihm.FabriqueIhm;
import pndgV3.ihm.OutilsGUI;

import java.awt.*;

public abstract class Sprite {
    private TypeSprite sonType;
    private Point coords;
    private Dimension dims;

    protected boolean visible;
    protected boolean dead;

    public Sprite(Point unPt, TypeSprite type){
        coords= unPt;
        sonType= type;
        dims = FabriqueIhm.getDimensions(type);

        visible = true;
        dead = false;
    }
    public Sprite( int x, int y, TypeSprite type) {
        coords = new Point(x,y);
        sonType= type;
        dims = FabriqueIhm.getDimensions(type);

        visible = true;
        dead = false;
    }

    public TypeSprite getSonType() {
        return sonType;
    }

    public boolean isDead() {
        return dead;
    }

    public void setCoords( Point coords ) {
        this.coords = coords;
    }

    public int getX() {
        return coords.x;
    }
    public int getY() {
        return coords.y;
    }

    public int getWidth() {
        return (int) dims.getWidth();
    }
    public int getHeight() {
        return (int)dims.getHeight();
    }

    /**
     * Méthode chargée de réaliser le déplacement demandé.
     * @param dx: int
     * @param dy: int
     */
    public void move(int dx,int dy){
        //System.out.println(" move() like a "+this.getClass().getSimpleName().toUpperCase());
        //System.out.println("TYPE="+sonType);
        int newX= coords.x+dx;
        int newY= coords.y+dy;

        coords = new Point(newX, newY);
        if(sonType!= TypeSprite.MONTAGNE) {
            if (!OutilsGUI.etreDansEcran(coords)) {
                System.out.println("sorti");
                visible = false;
            }
        }
    }


    public boolean isVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public void mourrir(){
        dead = true;
    }

    public String toString(){
        return "en [x:"+getX()+": y="+getY()+"]";
    }
}
