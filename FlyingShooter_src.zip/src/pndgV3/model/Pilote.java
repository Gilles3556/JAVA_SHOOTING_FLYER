package pndgV3.model;

import pndgV3.ihm.Commons;

public class Pilote {
    private int pv;
    private int km;
    private int palmares;
    private String nom;

    public Pilote( String nom ) {
        this.nom = nom;
        this.pv=30;
        this.km=0;
        this.palmares =0;
    }

    public void parcourir(int distance){
        km+=distance;
    }

    public void etreTouche(TypeSprite t){
        int degat = Commons.DEGAT_COLLISSION_DFLT;

        if( t==TypeSprite.ALIEN){
          degat =  Commons.DEGAT_COLLISSION_WITH_ALIEN;
        }else{
            if(t==TypeSprite.MONTAGNE) {
                degat = Commons.DEGAT_COLLISION_WITH_MONTAGNE;
            }
        }
        pv = pv-degat;
    }

    public void abbattreUnAlien(){
        this.palmares+=1;
    }

    public boolean etreMort(){
        return (pv<=0);
    }
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Pilote: [");
        sb.append(nom).append("] ");
        sb.append("| pv:").append(String.format("%03d",pv));
        sb.append("|| km=").append(String.format("%03d",km));
        sb.append("| ENI=").append(String.format("%03d",palmares));

        return sb.toString();
    }
}
