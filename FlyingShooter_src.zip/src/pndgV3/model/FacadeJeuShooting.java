package pndgV3.model;

import pndgV3.ihm.Commons;
import pndgV3.ihm.OutilsGUI;
import pndgV3.ihm.ShootingMissilesFenetre;

import javax.swing.*;
import java.util.*;
import java.util.Timer;

public class FacadeJeuShooting {
    private SpaceShip spaceShip;
    private List<Alien> lesAliens;
    private List<Montagne> lesSommetsDuBas;
    private Pilote unPilote;
    private int idxSommet;

    public Pilote getUnPilote() {
        return unPilote;
    }

    public SpaceShip getSpaceShip() {
        return spaceShip;
    }

    public List<Alien> getLesAliens() {
        return lesAliens;
    }

    public List<Montagne> getLesSommetsDuBas() {
        return lesSommetsDuBas;
    }

    public int getIdxSommet() {
        return idxSommet;
    }

    public FacadeJeuShooting(){
       idxSommet = 0;
       initAliens();
       initSommets();
       initVaisseau();
       unPilote = new Pilote("Polo");
    }

    private void initVaisseau(){
        spaceShip = new SpaceShip(Commons.ICRAFT_X, Commons.ICRAFT_Y);
    }
    /**
     * Méthode chargée d'initialiser les aliens.
     */
    public void initAliens(){
        lesAliens = new ArrayList<Alien>();
        Random rd = new Random();
        int nbAlien = rd.nextInt(10)+1;
        for(int i = 0; i< Commons.MAX_ALIENS; i++){
            int x= Commons.WIDTH_DFLT/2+rd.nextInt(Commons.WIDTH_DFLT/2)+20;
            int y = rd.nextInt(Commons.HEIGHT_DFLT/2);

            Alien unAlien = FabriqueMetier.creerAlien(x,y);
            lesAliens.add(unAlien);
        }
    }

    /**
     * Méthode chargée d'initialiser les Sommets.
     * (LE tableau des coordonnées est déclaré dans Commons
     * @see {Commons.TABLEAU_Y_SOMMETS}
     */
    private void initSommets(){
        idxSommet = 0;
        lesSommetsDuBas = new ArrayList<Montagne>();
        lesSommetsDuBas.add(initNewMontagne());
        lesSommetsDuBas.add(initNewMontagne());
        lesSommetsDuBas.add(initNewMontagne());
    }

    public Montagne initNewMontagne(){
        //System.out.println("initNewMontagne() idx="+idxSommet);

        Montagne uneMontagne = new Montagne(Commons.TABLEAU_Y_SOMMETS[idxSommet]);
        lesSommetsDuBas.add(uneMontagne);
        if (idxSommet< Commons.MAX_SOMMET-1) {
            idxSommet = idxSommet+1;
        }else{
            idxSommet=0;
        }
        return uneMontagne;
    }

    public boolean allAliensPassed(){
        return (lesAliens.size() == 0);
    }

    public void supprimerUnAlien( Alien a){
        lesAliens.remove(a);
        unPilote.abbattreUnAlien();
    }
    public void supprimerUnMissile(int idx){
        getSpaceShip().getMissiles().remove(idx);
    }

    public boolean tirerSurAliens( Missile m){
        boolean touche=false;
        int idx=0;
        Alien a=null;
        while(!touche && idx < getLesAliens().size()){
            a = getLesAliens().get(idx);
            touche = m.toucherAlienAt(a.getX(),a.getY());
            if (!touche) {
                idx++;
            }
        }
        if (touche){
            supprimerUnAlien(a);
        }
        return touche;
    }

    /**
     * Méthode chargée de faire bouger les Sprites selon leur méthode.
     * @param spr: Sprite
     */
    public void bouger( Sprite spr){

        if (spr instanceof Alien){
            ((Alien) spr).move();
        }
        if (spr instanceof Missile){
            ((Missile)spr).move();
        }
        if(spr instanceof SpaceShip){
            ((SpaceShip)spr).move();
        }

        if (spr instanceof Montagne){
            ((Montagne)spr).move();
        }
    }

    public void finir( TypeSprite t, ShootingMissilesFenetre fen ){
        this.spaceShip.mourrir();
        if(t==TypeSprite.ALIEN) {
            fen.postMessage(Commons.MSG_FIN_COLLISION_WITH_ALIEN);
        }else {
            if(t==TypeSprite.MONTAGNE) {
                fen.postMessage(Commons.MSG_FIN_COLLISION_WITH_MONTAGNE);
            }
        }
        //MEP d'un Timer pour quitter
        OutilsGUI.terminer();
    }
}
