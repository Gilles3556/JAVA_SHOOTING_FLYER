package pndgV3.model;


import pndgV3.ihm.Commons;


public class Missile extends Sprite {

    public Missile( int x, int y) {
        super(x, y, TypeSprite.MISSILE);
    }

    public void move() {
       //System.out.println(" move() like a "+this.getClass().getSimpleName().toUpperCase());
        move (Commons.MISSILE_SPEED,0);
    }

    public boolean toucherAlienAt(int ax, int ay){
        boolean touche =false;

        boolean xOk= (getX()>= ax && getX()<=ax+Commons.SPRITE_SIZE);
        boolean yOk = (getY()>=ay && getY()<=ay+Commons.SPRITE_SIZE);

         if(yOk && xOk){
             touche = true;
        }

        return touche;
    }
    public String toString(){
        return this.getClass().getSimpleName().toUpperCase()+super.toString();
    }
}
