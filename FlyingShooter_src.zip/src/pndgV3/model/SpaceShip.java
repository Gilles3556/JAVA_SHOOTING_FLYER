package pndgV3.model;

import pndgV3.ihm.Commons;
import pndgV3.ihm.OutilsGUI;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class SpaceShip extends Sprite {

    private int dx;
    private int dy;
    private List<Missile> missiles;

    public SpaceShip( int x, int y) {
        super(x, y, TypeSprite.SPACESHIP);
        missiles = new ArrayList<>();
    }

    public void move() {
        move(dx,dy);
    }

    public List<Missile> getMissiles() {
        return missiles;
    }

    public void fire() {
        missiles.add(FabriqueMetier.creerMissile(getX() + getWidth(), getY() + getHeight() / 2));
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_SPACE) {
            fire();
        }

        if (key == KeyEvent.VK_LEFT) {
            dx = -1;
            if (OutilsGUI.isSortiGauche(getX()+dx)){
                dx=0;
            }
        }

        if ( key == KeyEvent.VK_RIGHT) {
            //System.out.println("w="+ getWidth()+": h="+getHeight());

            dx = 1;
            if (OutilsGUI.isSortiDroite(getX()+dx)){
                dx=0;
            }
        }

        if (key == KeyEvent.VK_UP) {
            dy = -1;
            if (OutilsGUI.isSortiEnHaut(getY()+dy)){
                dy=0;
            }
        }

        if (key == KeyEvent.VK_DOWN) {
            dy = 1;
            if (OutilsGUI.isSortiEnBas(getY()+dy)){
                dy=0;
            }
        }
    }

    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT) {
            dx = 0;
        }
        if (key == KeyEvent.VK_UP || key == KeyEvent.VK_DOWN) {
            dy = 0;
        }
    }

    /**
     * Méthode chargée de répondre si le VAISSEAU a été touché par une Montagne qui est en [x:y].
     * @param mx: int
     * @param my: int
     * @return boolean
     */
    public boolean touchedByMontagneAt( int mx, int my){
        boolean touche = false;
        if(mx>0) {
            if (getX() >= mx && getY() >= my-20) {
                touche = true;
                System.out.println(String.format(" MONTAGNE=[%d:%d] V=[%d;%d] touché=%b",
                         my, mx, getY(), getX(), touche));
            }
        }
        return touche;
    }

    /**
     * Méthode chargée de répondre si le VAISSEAU a été touché par un Alien qui est en [x:y].
     * @param ax: int
     * @param ay: int
     * @return boolean
     */
    public boolean touchedByAlienAt( int ax, int ay){
        boolean touche = false;

        boolean xOk= (getX()>= ax && getX()<=ax+ Commons.SPRITE_SIZE);
        boolean yOk = (getY()>=(ay-Commons.SPRITE_SIZE/2) && getY()<=ay+(Commons.SPRITE_SIZE/2));

        if (xOk && yOk ) {
            touche = true;
            System.out.println(String.format(" ALIEN=[%d:%d] V=[%d;%d] touché=%b",
                    ay,ax,getY(),getX(),touche));
        }
        return touche;

    }
    public String toString(){
        return this.getClass().getSimpleName().toUpperCase()+" "+super.toString();
    }
}

