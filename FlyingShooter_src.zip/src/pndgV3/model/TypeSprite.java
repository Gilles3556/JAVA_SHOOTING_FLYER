package pndgV3.model;

public enum TypeSprite {
    ALIEN,MISSILE,MONTAGNE,SPACESHIP,EXPLOSION;
}
