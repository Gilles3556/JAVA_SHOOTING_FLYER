package pndgV3.model;

public final class FabriqueMetier {
    private FabriqueMetier(){}


    public static Missile creerMissile( int x, int y ) {
        return new Missile(x,y);
    }
    public static SpaceShip creerVaisseau(int x, int y){
        return new SpaceShip(x,y);
    }
    public static Alien creerAlien( int x, int y){ return new Alien(x,y);}
    public static Montagne creerMontagne( int y){ return new Montagne(y);}

    public static FacadeJeuShooting creerJeuShooting() {
        return new FacadeJeuShooting();
    }
}
