package pndgV3.start;

import pndgV3.presenter.Presenter;

public class LanceurV3 {
    public static  void main( String[] args ) {
        Presenter pres = new Presenter();
        pres.exec();
    }
}
