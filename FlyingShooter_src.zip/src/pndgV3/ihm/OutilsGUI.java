package pndgV3.ihm;

import pndgV3.model.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class OutilsGUI {

    private OutilsGUI(){}

    /**
     * Méthode chargée de détecter si un point est sortie des dimensions.
     * @param pt: Point
     * @return boolean
     */
    public static  boolean etreDansEcran(Point pt){
        boolean dedans = true;

        if (OutilsGUI.isSortiEnBas(pt.y) || OutilsGUI.isSortiEnHaut(pt.y)
                || OutilsGUI.isSortiDroite(pt.x) || OutilsGUI.isSortiGauche(pt.x)) {
            dedans  = false;

        }
        return dedans;
    }
    /**
     * Méthode chargée de controler que y sort par le haut.
     * @param y: int, le y à vérifier
     * @return boolean
     */
    public static  boolean isSortiEnHaut(int y){
        boolean sorti =(y < Commons.MIN_HAUT);
        if (sorti) {
            System.out.println("est sorti en Y=" + y);
        }
        return sorti;
    }

    /**
     * Méthode chargée de controler que y sort par le bas.
     * @param y: int, le y à vérifier
     * @return boolean
     */
    public static  boolean isSortiEnBas(int y){
        boolean sorti =(y > Commons.MAX_BAS);
        if (sorti) {
            System.out.println("est sorti en Y=" + y);
        }
        return sorti;
    }

    /**
     * Méthode chargée de controler que x sort par la DROITE.
     * @param x: int, le x à vérifier
     * @return boolean
     */
    public static boolean isSortiDroite(int x){
        x = x+40;
        boolean sorti=(x> Commons.MAX_DROITE);
        if(sorti) {
            System.out.println("est sorti D en X=" + x);
        }
        return sorti;
    }

    /**
     * Méthode chargée de controler que x sort par la GAUCHE.
     * @param x: int, le x à vérifier
     * @return boolean
     */
    public  static  boolean isSortiGauche( int x ){
        boolean sorti=(x<= Commons.MIN_GAUCHE);
       if(sorti) {
            System.out.println("est sorti G en X=" + x);
        }
        return sorti;
    }

    public static void dessinerVaisseau( Graphics2D g2d, JPanel jpan, SpaceShip leVaisseau){
        g2d.drawImage(FabriqueIhm.creerImage(TypeSprite.SPACESHIP),
                      leVaisseau.getX(),
                      leVaisseau.getY(), jpan);
    }
    /**
     * Méthode chargée de dessiner chaque Missile.
     * @param g2d: Graphics2D le contexte graphique
     * @param jpan: JPanel
     * @param missiles: List<Missile>
     */
    public static void dessinerMissiles( Graphics2D g2d, JPanel jpan, List<Missile> missiles ) {
        for (Missile m : missiles) {
            g2d.drawImage(FabriqueIhm.creerImage(TypeSprite.MISSILE),
                           m.getX(),
                           m.getY(), jpan);
        }
    }

    /**
         * Méthode chargée de dessiner chaque Alien.
     * @param g2d: Graphics2D le contexte graphique
     * @param jpan: JPanel
     * @param lesAliens: List<Alien>
     */
    public static void dessinerAliens( Graphics2D g2d, JPanel jpan, List<Alien> lesAliens ) {
        for(Alien a: lesAliens){
            g2d.drawImage(FabriqueIhm.creerImage(TypeSprite.ALIEN),
                          a.getX(),
                          a.getY(),
                          jpan);
        }
    }

    /**
     * Méthode chargée de dessiner chaque Montagne.
     * @param g2d: Graphics2D le contexte graphique
     * @param jpan: JPanel
     * @param lesMonts: List<Montagnes>
     */
    public static void dessinerMontagnes( Graphics2D g2d, JPanel jpan, List<Montagne> lesMonts ) {

        for(Montagne m: lesMonts){
            if(!m.isTouched()) {
                g2d.setColor(Color.green);
                g2d.setStroke(new BasicStroke(15));

                g2d.drawLine(m.getX(), m.getY(), m.getX(), Commons.HEIGHT_DFLT);
                //g2d.drawRect (m.getX(),m.getY(),25 ,Commons.HEIGHT_DFLT);
            }
        }
    }
    public static void terminer(){
        //MEP d'un timer pour fermer la fenêtre
        TimerTask task = new TimerTask() {
            public void run() {
                System.out.println("Fin du JEU");
                System.exit(0);
            }
        };
        java.util.Timer timer = new Timer("Timer");
        timer.schedule(task, 3000L);

    }
}