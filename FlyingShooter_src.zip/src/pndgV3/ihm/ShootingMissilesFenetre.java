package pndgV3.ihm;

import pndgV3.model.FacadeJeuShooting;

import javax.swing.*;

public class ShootingMissilesFenetre extends JFrame {
    private Board aBoard;
    private JPanel conteneur;
    private JLabelPilote jlabp;
    private JLabel jlabMsg;
    private FacadeJeuShooting fjs;

    public JLabelPilote getJlabp() {
        return jlabp;
    }

    public ShootingMissilesFenetre( FacadeJeuShooting fjs) {
        this.fjs = fjs;
        initUI(fjs);
    }

    private void initUI( FacadeJeuShooting fjs ) {
        //MEP d'un JPanel
        conteneur = new JPanel();

        //Box Layout en colonne
        conteneur.setLayout(new BoxLayout(conteneur, BoxLayout.PAGE_AXIS));
        jlabp = new JLabelPilote(fjs.getUnPilote());
        conteneur.add(jlabp);

        aBoard = new Board(fjs,this);
        conteneur.add(aBoard);
        jlabMsg = new JLabel("...");
        conteneur.add(jlabMsg);

        setContentPane(conteneur);
        setSize(Commons.WIDTH_DFLT, Commons.HEIGHT_DFLT);
        setResizable(false);

        setTitle("Shooting missiles V2");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }


    public void setInfosPilote(){
        jlabp.setInfos(fjs.getUnPilote().toString());
    }

    public void postMessage(String msg){
        jlabMsg.setText(msg.toUpperCase());
    }
}
