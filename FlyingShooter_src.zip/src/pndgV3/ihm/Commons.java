package pndgV3.ihm;

public final class Commons {

    public static final int SPRITE_SIZE=12;
    public static final String MSG_FIN_COLLISION_WITH_ALIEN = "FIN: COLLISION avec un alien";
    public static final String MSG_FIN_COLLISION_WITH_MONTAGNE = "FIN: COLLISION avec une montagne";

    public static final int DEGAT_COLLISSION_DFLT =1;
    public static final int DEGAT_COLLISION_WITH_MONTAGNE = 3 ;
    public static int DEGAT_COLLISSION_WITH_ALIEN=2;

    private Commons(){    }

    public final static String IMG_ALIEN="src/resources/alien.png";
    public final static String IMG_MISSILE="src/resources/missile.png";
    public final static String IMG_MONTAGNE="";
    public final static String IMG_SPACESHIP="src/resources/spaceship.png";
    public final static String IMG_EXPLOSION="src/resources/explosion.png";

    public static final int MISSILE_SPEED = 2;
    public static final int MONTAGNE_SPEED = 3;
    public static final int ALIEN_SPEED = 1;

    public final static int X_DEPART=482;
    public static final int MAX_ALIENS = 7;
    public static final int WIDTH_DFLT = 500;
    public static final int HEIGHT_DFLT = 400;

    public final static int MIN_HAUT=2;
    public final static int MAX_BAS=HEIGHT_DFLT-2;
    public final static int MIN_GAUCHE=0;
    public final static int MAX_DROITE=WIDTH_DFLT;

    public static  final int ICRAFT_X = 40;
    public static final int ICRAFT_Y = 60;
    public static  final int DELAY = 12;

     public static final int[] TABLEAU_Y_SOMMETS = {
            300,300,300,300,300,
            150,150,150,150,150,
            400,400,400,400,400,
            200,200,200,200,200,
            380,380,380,380,380,
            360,360,360,360,360,
            350,350,350,350,350,
            340,340,340,340,340,
            400,400,400,400,400,
            400,400,400,400,400,
            380,380,380,380,380,
            220,220,220,220,220,
            350,350,350,350,350,
            340,340,340,340,340,
            240,240,240,240,240,
            280,280,280,280,280,
            250,250,250,250,250,
            280,280,280,280,280,
            300,300,300,300,300
    };

    public static final int MAX_SOMMET = TABLEAU_Y_SOMMETS.length;

}
