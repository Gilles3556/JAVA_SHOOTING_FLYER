package pndgV3.ihm;

import pndgV3.model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

public class Board extends JPanel implements ActionListener {
    private FacadeJeuShooting leJeu;
    private Timer timer;
    private ShootingMissilesFenetre fen;

    public Board( FacadeJeuShooting leJeu,ShootingMissilesFenetre fenParent) {
        this.fen = fenParent;
        this.leJeu = leJeu;
        initBoard();
    }
    private void initTitle(){
        fen.setTitle(fen.getTitle()+leJeu.getUnPilote().toString());
        fen.repaint();
    }
    private void initBoard() {
        initTitle();
        addKeyListener(new TAdapter());
        setBackground(Color.BLACK);
        setFocusable(true);

        timer = new Timer(Commons.DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
        Toolkit.getDefaultToolkit().sync();
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        // Dessin du vaisseau
        OutilsGUI.dessinerVaisseau(g2d,this,leJeu.getSpaceShip());

        // Dessin des missiles
        OutilsGUI.dessinerMissiles(g2d,this,leJeu.getSpaceShip().getMissiles());

        // Dessin des Aliens
        OutilsGUI.dessinerAliens(g2d,this,leJeu.getLesAliens());

        //DESSIN des montagnes
        OutilsGUI.dessinerMontagnes(g2d,this, leJeu.getLesSommetsDuBas());

        //MAJ infos pilote
        fen.setInfosPilote();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateMontagnes();
        updateAliens();
        updateMissiles();
        updateSpaceShip();

        repaint();
    }

    private void updateMontagnes(){
        leJeu.initNewMontagne();

          int i=0;
          boolean collision = false;
          do {
              Montagne m = leJeu.getLesSommetsDuBas().get(i);
              if (m.isVisible() && !m.isTouched()) {
                  if (leJeu.getSpaceShip().touchedByMontagneAt(m.getX(), m.getY())) {
                      m.etreTouche();

                      collision =true;

                      leJeu.getUnPilote().etreTouche(TypeSprite.MONTAGNE);
                      if (leJeu.getUnPilote().etreMort()) {
                          timer.stop();
                          leJeu.finir(TypeSprite.MONTAGNE,fen);
                      }
                  } else {
                      //System.out.println("leJeu.bouger()"+m.toString());
                      leJeu.bouger(m);
                  }
              } else {
                     m.setVisible(false);
              }
              if(!collision)
                  i++;
          }while(!collision && i<leJeu.getLesSommetsDuBas().size());
          if (!collision)
             leJeu.getUnPilote().parcourir(1  );
      }

    private void updateAliens(){

        int i=0;
        boolean collision = false;
        do {
            if(leJeu.getLesAliens().size()>0) {
                Alien alf = leJeu.getLesAliens().get(i);
                if (alf.isVisible()) {
                    if (leJeu.getSpaceShip().touchedByAlienAt(alf.getX(), alf.getY())) {
                        leJeu.getUnPilote().etreTouche(TypeSprite.ALIEN);

                        collision = true;
                        leJeu.supprimerUnAlien(alf);

                        if (leJeu.getUnPilote().etreMort()) {
                            timer.stop();

                            System.out.println(alf);
                            System.out.println(leJeu.getSpaceShip());

                            leJeu.finir(TypeSprite.ALIEN,fen);
                        }

                    } else {
                        leJeu.bouger(alf);
                    }
                } else {
                    leJeu.supprimerUnAlien(alf);
                }
                if (!collision)
                    i++;
            }else{
                i=9999;
            }
        }while(!collision && i<leJeu.getLesAliens().size());

        if(leJeu.allAliensPassed()){
            leJeu.initAliens();
        }
    }

    private void updateMissiles() {
        List<Missile> missiles = leJeu.getSpaceShip().getMissiles();
        for (int i = 0; i < missiles.size(); i++) {
            Missile missile = missiles.get(i);
            if (missile.isVisible()) {
                if(leJeu.tirerSurAliens(missile)) {
                    leJeu.supprimerUnMissile(i);
                }else{
                    leJeu.bouger(missile);
                }
            } else {
               leJeu.supprimerUnMissile(i);

            }
        }
    }

    private void updateSpaceShip() {
        leJeu.bouger(leJeu.getSpaceShip());
    }

    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
            leJeu.getSpaceShip().keyReleased(e);
        }

        @Override
        public void keyPressed(KeyEvent e) {
            leJeu.getSpaceShip().keyPressed(e);
        }
    }
}