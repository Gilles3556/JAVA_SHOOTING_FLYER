package pndgV3.ihm;

import pndgV3.model.TypeSprite;

import javax.swing.*;
import java.awt.*;
import java.util.Objects;

public final class FabriqueIhm {
    private FabriqueIhm(){}

    /**
     * Méthode chargée de renvoyer l'image correspondant au type de sprite.
     * @param leType: TypeSprite
     * @return Image
     */
    public static Image creerImage( TypeSprite leType ){
        ImageIcon img =null;
        switch (leType.name()){
            case "ALIEN": //Alien
                img = new ImageIcon(Commons.IMG_ALIEN);
                break;
            case "MISSILE": //Missile
                img = new ImageIcon(Commons.IMG_MISSILE);
                break;
            case "MONTAGNE": //Montagne
                //img = new ImageIcon(Commons.IMG_MONTAGNE);
                break;
            case "SPACESHIP": //SpaceShip
                img = new ImageIcon(Commons.IMG_SPACESHIP);
                break;
            case  "EXPLOSION": //Explosion
                img = new ImageIcon(Commons.IMG_EXPLOSION);
                break;
        }
        if (Objects.isNull(img)) {
            return null;
        }
        return img.getImage();
    }

    /**
     * Méthode chargée de renvoyer les dimension de l'image d'un sprite.
     * @param leType: TypeSprite
     * @return Dimension
     */
    public static Dimension getDimensions(TypeSprite leType){
        Dimension dim =null;

        Image img = creerImage(leType);
        if (img!=null){
            dim = new Dimension(img.getWidth(null),img.getHeight(null));
        }
        return dim;
    }



}
