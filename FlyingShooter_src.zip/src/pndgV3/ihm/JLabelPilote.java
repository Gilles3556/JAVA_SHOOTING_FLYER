package pndgV3.ihm;

import pndgV3.model.Pilote;

import javax.swing.*;

public class JLabelPilote extends JLabel {
    private Pilote unPilote;

    public JLabelPilote( Pilote unPilote ) {
        super(unPilote.toString());

        this.unPilote = unPilote;
    }

    public void setInfos(String infos){
        setText(infos);
    }
}
