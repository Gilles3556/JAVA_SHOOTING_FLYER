package pndgV3.presenter;

import pndgV3.ihm.ShootingMissilesFenetre;
import pndgV3.model.FabriqueMetier;
import pndgV3.model.FacadeJeuShooting;


import java.awt.*;

public class Presenter {

    private FacadeJeuShooting leJeu;
    ShootingMissilesFenetre ihm;

    public Presenter() {
        leJeu = FabriqueMetier.creerJeuShooting();
        ihm = new ShootingMissilesFenetre(leJeu);
    }

    public void exec() {
        EventQueue.invokeLater(() -> {
            ihm.setVisible(true);
        });
    }
}
